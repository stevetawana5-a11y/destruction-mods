package com.example.destruction;

import net.minecraft.block.BlockState;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemUsageContext;
import net.minecraft.item.tooltip.TooltipType;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

import java.util.List;

public class DestructionWandItem extends Item {
    private static final int SPHERE_RADIUS = 5;
    private static final float EXPLOSION_POWER = 8.0f;
    private static final int COOLDOWN_TICKS = 20;

    public DestructionWandItem(Settings settings) {
        super(settings);
    }

    @Override
    public ActionResult useOnBlock(ItemUsageContext ctx) {
        World world = ctx.getWorld();
        if (world.isClient) return ActionResult.SUCCESS;

        PlayerEntity player = ctx.getPlayer();
        BlockPos center = ctx.getBlockPos();

        if (player != null && player.isSneaking()) {
            world.createExplosion(null,
                    center.getX() + 0.5, center.getY() + 0.5, center.getZ() + 0.5,
                    EXPLOSION_POWER, true, World.ExplosionSourceType.TNT);
        } else {
            destroySphere((ServerWorld) world, center, SPHERE_RADIUS, player);
        }

        if (player != null) player.getItemCooldownManager().set(this, COOLDOWN_TICKS);
        return ActionResult.SUCCESS;
    }

    /** Détruit tous les blocs (hors bedrock & co) dans une sphère. Retourne le nombre de blocs cassés. */
    public static int destroySphere(ServerWorld world, BlockPos center, int radius, PlayerEntity player) {
        int count = 0;
        int r2 = radius * radius;
        BlockPos.Mutable pos = new BlockPos.Mutable();
        for (int dx = -radius; dx <= radius; dx++) {
            for (int dy = -radius; dy <= radius; dy++) {
                for (int dz = -radius; dz <= radius; dz++) {
                    if (dx * dx + dy * dy + dz * dz > r2) continue;
                    pos.set(center.getX() + dx, center.getY() + dy, center.getZ() + dz);
                    BlockState state = world.getBlockState(pos);
                    if (state.isAir() || state.getHardness(world, pos) < 0) continue; // bedrock, etc.
                    if (world.breakBlock(pos, true, player)) count++;
                }
            }
        }
        return count;
    }

    @Override
    public void appendTooltip(ItemStack stack, TooltipContext context, List<Text> tooltip, TooltipType type) {
        tooltip.add(Text.translatable("item.destruction.destruction_wand.tooltip"));
    }
}
