package com.example.destruction;

import com.mojang.brigadier.arguments.FloatArgumentType;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.world.World;

public class DestructionMod implements ModInitializer {
    public static final String MOD_ID = "destruction";
    public static Item DESTRUCTION_WAND;

    @Override
    public void onInitialize() {
        DESTRUCTION_WAND = Registry.register(
                Registries.ITEM,
                Identifier.of(MOD_ID, "destruction_wand"),
                new DestructionWandItem(new Item.Settings().maxCount(1)));

        ItemGroupEvents.modifyEntriesEvent(ItemGroups.TOOLS)
                .register(entries -> entries.add(DESTRUCTION_WAND));

        // /nuke [puissance] : explosion massive sous le joueur (op uniquement)
        // /crater [rayon]   : creuse une sphère autour du joueur
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
            dispatcher.register(CommandManager.literal("nuke")
                    .requires(src -> src.hasPermissionLevel(2))
                    .then(CommandManager.argument("puissance", FloatArgumentType.floatArg(1f, 50f))
                            .executes(ctx -> {
                                ServerPlayerEntity p = ctx.getSource().getPlayerOrThrow();
                                float power = FloatArgumentType.getFloat(ctx, "puissance");
                                p.getServerWorld().createExplosion(null, p.getX(), p.getY(), p.getZ(),
                                        power, true, World.ExplosionSourceType.TNT);
                                return 1;
                            })));

            dispatcher.register(CommandManager.literal("crater")
                    .requires(src -> src.hasPermissionLevel(2))
                    .then(CommandManager.argument("rayon", IntegerArgumentType.integer(1, 32))
                            .executes(ctx -> {
                                ServerPlayerEntity p = ctx.getSource().getPlayerOrThrow();
                                int r = IntegerArgumentType.getInteger(ctx, "rayon");
                                int n = DestructionWandItem.destroySphere(p.getServerWorld(), p.getBlockPos(), r, p);
                                ctx.getSource().sendFeedback(() -> Text.literal(n + " blocs détruits"), false);
                                return n;
                            })));
        });
    }
}
