# Destruction (Fabric 1.21.1)

- **Baguette de destruction** (onglet Outils) :
  - clic droit sur un bloc → détruit une sphère de rayon 5 (les blocs droppent)
  - accroupi + clic droit → explosion de puissance 8
- `/nuke <puissance 1-50>` : explosion à ta position (op)
- `/crater <rayon 1-32>` : creuse une sphère autour de toi (op)

## Compiler
Java 21 requis.
1. Ajoute le wrapper Gradle : `gradle wrapper --gradle-version 8.10` (ou copie celui du template Fabric)
2. `./gradlew build`
3. Le .jar est dans `build/libs/` → à mettre dans `mods/` avec Fabric Loader + Fabric API.

Réglages (rayon, puissance, cooldown) : constantes en haut de `DestructionWandItem.java`.
